import { Icon, Text, useTheme } from '@rneui/themed';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ProfileCard } from '../../components/ProfileCard'; // <---
import { supabase } from '../../lib/supabase';

export default function GlobalSearchScreen() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (query.trim().length > 1) handleSearch();
      else setResults([]);
    }, 500);
    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  async function handleSearch() {
    setLoading(true);
    // Ищем по имени или описанию
    const { data } = await supabase
        .from('global_search_view')
        .select('*')
        .or(`full_name.ilike.%${query}%,description.ilike.%${query}%`)
        .limit(20);
    
    if (data) setResults(data);
    setLoading(false);
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background, paddingTop: insets.top }]}>
        {/* Header Search */}
        <View style={styles.header}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
                <Icon name="arrow-left" type="feather" color={theme.colors.black} />
            </TouchableOpacity>
            
            <View style={[styles.searchWrapper, { backgroundColor: theme.colors.grey0, borderColor: theme.colors.grey1 }]}>
                <Icon name="search" type="feather" size={18} color={theme.colors.grey2} />
                <TextInput 
                    autoFocus 
                    style={[styles.input, { color: theme.colors.black }]} 
                    placeholder="Маникюр, плов, массаж..." 
                    placeholderTextColor={theme.colors.grey3}
                    value={query} 
                    onChangeText={setQuery} 
                />
                {loading && <ActivityIndicator size="small" color={theme.colors.primary} />}
            </View>
        </View>

        <FlatList
            data={results}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
                // Используем наш красивый компонент
                <ProfileCard item={item} type={item.role === 'venue' ? 'venue' : 'specialist'} />
            )}
            contentContainerStyle={{ padding: 20 }}
            ListEmptyComponent={
                <View style={styles.empty}>
                    <Text style={{ fontSize: 40 }}>🧐</Text>
                    <Text style={[styles.emptyText, { color: theme.colors.grey2 }]}>
                        {query.length > 1 ? 'Ничего не найдено' : 'Начните вводить запрос'}
                    </Text>
                </View>
            }
        />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 10 },
  backBtn: { padding: 5 },
  searchWrapper: { 
      flex: 1, flexDirection: 'row', alignItems: 'center', 
      paddingHorizontal: 15, borderRadius: 16, height: 50,
      borderWidth: 1
  },
  input: { flex: 1, marginLeft: 10, fontSize: 16, height: '100%' },
  empty: { alignItems: 'center', marginTop: 100 },
  emptyText: { marginTop: 10, fontSize: 16 }
});