import { Icon, useTheme } from '@rneui/themed';
import { Tabs } from 'expo-router';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function ClientLayout() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets(); // Получаем безопасные зоны
  const isDark = theme.mode === 'dark'; 

  return (
    <Tabs 
      screenOptions={{ 
        headerShown: false,
        tabBarStyle: { 
            backgroundColor: theme.colors.background,
            borderTopColor: isDark ? '#222' : '#eee',
            borderTopWidth: 1,
            
            // --- ФИКС ВЫСОТЫ (Android + iOS) ---
            // 60px (высота самих кнопок) + Безопасная зона снизу
            height: 60 + insets.bottom,
            
            // Отступ снизу: либо безопасная зона, либо 10px (если зоны нет)
            paddingBottom: insets.bottom > 0 ? insets.bottom : 10,
            
            elevation: 0, 
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: 'gray',
        tabBarShowLabel: false, 
      }}
    >
      {/* 5 КНОПОК */}
      <Tabs.Screen name="home" options={{ tabBarIcon: ({ color }) => <Icon name="search" type="feather" color={color} size={24} /> }} />
      <Tabs.Screen name="favorites" options={{ tabBarIcon: ({ color }) => <Icon name="heart" type="feather" color={color} size={24} /> }} />
      <Tabs.Screen name="reels" options={{ tabBarIcon: ({ color }) => <Icon name="play-circle" type="feather" color={color} size={28} /> }} />
      <Tabs.Screen name="orders" options={{ tabBarIcon: ({ color }) => <Icon name="calendar" type="feather" color={color} size={24} /> }} />
      <Tabs.Screen name="messages" options={{ tabBarIcon: ({ color }) => <Icon name="message-circle" type="feather" color={color} size={24} /> }} />

      {/* СКРЫТЫЕ */}
      <Tabs.Screen name="category-results" options={{ href: null }} />
      <Tabs.Screen name="ai-search" options={{ href: null }} />
      <Tabs.Screen name="add-review" options={{ href: null }} />
    </Tabs>
  );
}