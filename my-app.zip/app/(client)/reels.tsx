import { useIsFocused } from '@react-navigation/native';
import { Icon, Text, useTheme } from '@rneui/themed';
import { ResizeMode, Video } from 'expo-av';
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useRef, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Platform,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { UserAvatar } from '../../components/UserAvatar'; // <---
import { supabase } from '../../lib/supabase';

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get('window');

export default function ReelsScreen() {
  const { theme } = useTheme();
  const isFocused = useIsFocused();
  const insets = useSafeAreaInsets();
  
  const [videos, setVideos] = useState<any[]>([]);
  const [currentId, setCurrentId] = useState<any>(null);

  // === РАСЧЕТ ВЫСОТЫ ===
  // Если у тебя Tabs снизу, нам нужно вычесть их высоту, чтобы видео не залезало под них.
  // Стандартная высота табов ~50px + отступ снизу.
  // Если ты используешь translucent header, то status bar height не вычитаем.
  const BOTTOM_TAB_HEIGHT = 60 + (Platform.OS === 'ios' ? insets.bottom : 10);
  
  // Высота ячейки видео = Весь экран - Таббар
  // (Предполагаем, что header сверху скрыт, как в тиктоке)
  const ITEM_HEIGHT = SCREEN_HEIGHT - BOTTOM_TAB_HEIGHT;

  useFocusEffect(useCallback(() => {
      supabase.rpc('get_video_feed').then(({ data }) => { 
        if(data && data.length > 0) { 
            setVideos(data); 
            // Ставим первый как активный
            if (!currentId) setCurrentId(data[0].id);
        } 
      });
      // Не сбрасываем currentId при blur, чтобы при возврате видео не моргало
  }, []));

  // Оптимизация смены видео
  const onViewableItemsChanged = useRef(({ viewableItems }: any) => {
    if (viewableItems.length > 0) {
        const item = viewableItems[0].item;
        setCurrentId(item.id);
    }
  }).current;

  const renderItem = ({ item }: { item: any }) => {
    const isPlaying = item.id === currentId && isFocused;

    return (
        <View style={{ width: SCREEN_WIDTH, height: ITEM_HEIGHT, backgroundColor: 'black' }}>
            <Video 
                source={{ uri: item.file_url }} 
                style={StyleSheet.absoluteFill} 
                resizeMode={ResizeMode.COVER} // Cover заполняет весь экран красиво
                isLooping 
                shouldPlay={isPlaying} 
                isMuted={false}
            />

            {/* ЗАТЕМНЕНИЕ СНИЗУ (Градиент своими руками) */}
            <View style={styles.gradientOverlay} />

            {/* КОНТЕНТ ПОВЕРХ ВИДЕО */}
            <View style={styles.overlayContent}>
                
                {/* ЛЕВАЯ ЧАСТЬ: ИНФО */}
                <View style={{ flex: 1, paddingRight: 20 }}>
                    <TouchableOpacity 
                        style={styles.userInfo}
                        onPress={() => router.push(item.role === 'venue' ? `/venue-details/${item.user_id}` : `/specialist-details/${item.user_id}`)}
                    >
                        <UserAvatar avatarUrl={item.avatar_url} size={45} />
                        <Text style={styles.userName}>@{item.full_name}</Text>
                    </TouchableOpacity>

                    <Text style={styles.description} numberOfLines={3}>
                        {item.description}
                    </Text>
                </View>

                {/* ПРАВАЯ ЧАСТЬ: КНОПКИ */}
                <View style={styles.actionsColumn}>
                    <TouchableOpacity style={styles.actionBtn}>
                        <Icon name="heart" type="font-awesome" color="white" size={28} style={styles.shadow} />
                        <Text style={styles.actionText}>Like</Text>
                    </TouchableOpacity>

                    <TouchableOpacity 
                        style={styles.actionBtn}
                        onPress={() => router.push(`/chat/${item.user_id}`)}
                    >
                        <Icon name="message-circle" type="feather" color="white" size={30} style={styles.shadow} />
                        <Text style={styles.actionText}>Chat</Text>
                    </TouchableOpacity>
                    
                     <TouchableOpacity style={styles.actionBtn}>
                        <Icon name="share-2" type="feather" color="white" size={28} style={styles.shadow} />
                        <Text style={styles.actionText}>Share</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: 'black' }}>
      {/* Делаем статус бар прозрачным, чтобы видео было под ним */}
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
      
      <FlatList 
        data={videos} 
        renderItem={renderItem} 
        keyExtractor={item => item.id.toString()} 
        
        // МАГИЯ СКРОЛЛА
        pagingEnabled 
        snapToInterval={ITEM_HEIGHT}
        snapToAlignment="start"
        decelerationRate="fast"
        
        showsVerticalScrollIndicator={false} 
        onViewableItemsChanged={onViewableItemsChanged} 
        viewabilityConfig={{ itemVisiblePercentThreshold: 50 }} 
        
        // Оптимизация
        initialNumToRender={1}
        maxToRenderPerBatch={2}
        windowSize={3}
        
        // Layout
        getItemLayout={(_, index) => ({
            length: ITEM_HEIGHT,
            offset: ITEM_HEIGHT * index,
            index,
        })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  gradientOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    height: 300,
    backgroundColor: 'rgba(0,0,0,0.4)', // Прозрачный черный фон для текста
    // Если есть LinearGradient, лучше использовать его от transparent до black
  },
  overlayContent: { 
    position: 'absolute', 
    bottom: 20, 
    left: 0, 
    right: 0, 
    flexDirection: 'row', 
    alignItems: 'flex-end',
    paddingHorizontal: 15,
    paddingBottom: 10
  },
  userInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  userName: { color: 'white', fontWeight: 'bold', fontSize: 16, marginLeft: 10, textShadowColor: 'black', textShadowRadius: 3 },
  description: { color: 'rgba(255,255,255,0.9)', fontSize: 14, lineHeight: 20 },
  
  actionsColumn: { alignItems: 'center', gap: 20, marginLeft: 10 },
  actionBtn: { alignItems: 'center' },
  actionText: { color: 'white', fontSize: 10, marginTop: 4, fontWeight: '600' },
  shadow: { textShadowColor: 'black', textShadowRadius: 5 }
});