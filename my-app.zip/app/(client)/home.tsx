import { Icon, Text, useTheme } from '@rneui/themed';
import { router } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  RefreshControl,
  StyleSheet,
  TouchableOpacity,
  View
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';
import { Category } from '../../types/database';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const COLUMN_WIDTH = (SCREEN_WIDTH - 40 - 20) / 3; // 40 padding, 20 gap

export default function ClientHome() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [mode, setMode] = useState<'specialist' | 'venue'>('specialist');
  const [loading, setLoading] = useState(true);
  const insets = useSafeAreaInsets();

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('categories')
      .select('*')
      .eq('type', mode)
      .order('name');
    if (data) setCategories(data as Category[]);
    setLoading(false);
  }, [mode]);

  useEffect(() => { fetchCategories(); }, [fetchCategories]);

  // Компонент Категории
  const renderCategory = ({ item }: { item: Category }) => (
    <TouchableOpacity 
      activeOpacity={0.8}
      style={styles.catWrapper}
      onPress={() => router.push({ 
          pathname: '/(client)/category-results', 
          params: { id: item.id, name: item.name, type: mode } 
      } as any)}
    >
      <View style={[styles.catCard, { backgroundColor: theme.colors.grey0 }]}>
        {item.image_url ? (
          <Image source={{ uri: item.image_url }} style={styles.catImage} resizeMode="contain" />
        ) : (
          <Icon name="grid" type="feather" size={24} color={theme.colors.primary} />
        )}
      </View>
      <Text style={[styles.catName, { color: theme.colors.black }]} numberOfLines={2}>
        {item.name}
      </Text>
    </TouchableOpacity>
  );

  // Шапка списка (Header + AI Banner + Switcher)
  const ListHeader = () => (
    <View style={styles.headerContainer}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <View>
          <Text style={{ fontSize: 14, color: theme.colors.grey2 }}>Добро пожаловать,</Text>
          <Text h4 style={{ color: theme.colors.black, fontWeight: '800' }}>
            {user?.user_metadata?.full_name?.split(' ')[0] || 'Гость'}
          </Text>
        </View>
        <View style={styles.actionsRow}>
           <TouchableOpacity 
             style={[styles.iconBtn, { backgroundColor: theme.colors.grey0, borderColor: theme.colors.grey1 }]} 
             onPress={() => router.push('/notifications')}
           >
             <Icon name="bell" type="feather" size={20} color={theme.colors.black} />
           </TouchableOpacity>
           <TouchableOpacity 
             style={[styles.iconBtn, { backgroundColor: theme.colors.grey0, borderColor: theme.colors.grey1 }]} 
             onPress={() => router.push('/settings')}
           >
             <Icon name="settings" type="feather" size={20} color={theme.colors.black} />
           </TouchableOpacity>
        </View>
      </View>

      {/* AI Banner */}
      <TouchableOpacity 
        style={[styles.aiBanner, { backgroundColor: theme.colors.primary }]} 
        onPress={() => router.push('/(client)/ai-search')} 
        activeOpacity={0.9}
      >
        <View style={styles.aiContent}>
          <View style={styles.aiBadge}>
            <Text style={styles.aiBadgeText}>AI NEW</Text>
          </View>
          <Text style={styles.aiTitle}>Умный поиск</Text>
          <Text style={styles.aiSub}>Напишите "маникюр завтра" и мы найдем мастера</Text>
        </View>
        <View style={styles.aiIconBox}>
             <Icon name="sparkles" type="ionicon" color={theme.colors.primary} size={28} />
        </View>
      </TouchableOpacity>

      {/* Mode Switcher */}
      <View style={[styles.modeContainer, { backgroundColor: theme.colors.grey1 }]}>
        {(['specialist', 'venue'] as const).map((m) => {
            const isActive = mode === m;
            return (
              <TouchableOpacity 
                key={m}
                style={[styles.modeBtn, isActive && { backgroundColor: theme.colors.background, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, elevation: 2 }]}
                onPress={() => setMode(m)}
              >
                <Text style={[styles.modeText, { color: isActive ? theme.colors.black : theme.colors.grey2 }]}>
                  {m === 'specialist' ? 'Мастера' : 'Заведения'}
                </Text>
              </TouchableOpacity>
            )
        })}
      </View>

      <Text h4 style={[styles.sectionTitle, { color: theme.colors.black }]}>Категории</Text>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <FlatList
        data={categories}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderCategory}
        numColumns={3}
        ListHeaderComponent={ListHeader}
        columnWrapperStyle={styles.columnWrapper}
        contentContainerStyle={[styles.listContent, { paddingTop: insets.top + 10 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchCategories} tintColor={theme.colors.primary} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { paddingBottom: 100 },
  headerContainer: { paddingHorizontal: 20, marginBottom: 10 },
  
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  actionsRow: { flexDirection: 'row', gap: 10 },
  iconBtn: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center', borderWidth: 1 },

  aiBanner: { 
    borderRadius: 24, padding: 20, 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: 24,
    shadowColor: "#6366f1", shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.3, shadowRadius: 16, elevation: 8
  },
  aiContent: { flex: 1, paddingRight: 10 },
  aiBadge: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, alignSelf: 'flex-start', marginBottom: 8 },
  aiBadgeText: { color: 'white', fontSize: 10, fontWeight: 'bold' },
  aiTitle: { color: 'white', fontSize: 20, fontWeight: '800' },
  aiSub: { color: 'rgba(255,255,255,0.9)', fontSize: 13, marginTop: 4 },
  aiIconBox: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center' },

  modeContainer: { flexDirection: 'row', padding: 4, borderRadius: 16, marginBottom: 30 },
  modeBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 12 },
  modeText: { fontWeight: '700', fontSize: 14 },

  sectionTitle: { marginBottom: 15, paddingLeft: 5 },
  columnWrapper: { justifyContent: 'flex-start', gap: 10, paddingHorizontal: 20 },
  catWrapper: { width: COLUMN_WIDTH, marginBottom: 20, alignItems: 'center' },
  catCard: { 
      width: '100%', aspectRatio: 1, borderRadius: 20, 
      justifyContent: 'center', alignItems: 'center', marginBottom: 8,
      shadowColor: "#000", shadowOffset: {width: 0, height: 2}, shadowOpacity: 0.03, shadowRadius: 6, elevation: 2
  },
  catImage: { width: '50%', height: '50%' },
  catName: { fontSize: 12, fontWeight: '600', textAlign: 'center', lineHeight: 16 },
});