import { Icon, Text, useTheme } from '@rneui/themed';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Modal, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader } from '../../components/AppHeader';
import { ProfileCard } from '../../components/ProfileCard';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';

// Тип сортировки
type SortType = 'default' | 'price_asc' | 'price_desc' | 'rating';

export default function CategoryResultsScreen() {
  const { id, name, type } = useLocalSearchParams();
  const { theme } = useTheme();
  const { user } = useAuth(); 
  const insets = useSafeAreaInsets();

  const [allItems, setAllItems] = useState<any[]>([]); // Все загруженные
  const [filteredItems, setFilteredItems] = useState<any[]>([]); // То, что показываем
  const [loading, setLoading] = useState(true);

  // Состояния фильтров
  const [userCity, setUserCity] = useState<string>('');
  const [selectedCity, setSelectedCity] = useState<string | null>(null); 
  const [sortBy, setSortBy] = useState<SortType>('default');
  const [modalVisible, setModalVisible] = useState(false); 

  useEffect(() => { 
      // Определяем город юзера для дефолтного фильтра
      if (user?.user_metadata?.city) {
          setUserCity(user.user_metadata.city);
          setSelectedCity(user.user_metadata.city); // Сразу включаем фильтр по городу
      }
      fetchItems(); 
  }, [id]);

  // Когда меняем фильтры - пересчитываем список
  useEffect(() => {
      applyFilters();
  }, [selectedCity, sortBy, allItems]);

  async function fetchItems() {
    setLoading(true);
    
    // Используем global_search_view как основной источник
    let query = supabase.from('global_search_view').select('*').eq('category_name', name);
    
    const { data } = await query;
    
    // Если ищем специалистов, подтягиваем данные из таблицы спецов для цены
    if (type === 'specialist') {
        const { data: specData } = await supabase.from('specialist_search_view').select('*').eq('category_id', id);
        if (specData) setAllItems(specData);
    } else {
        // Для заведений используем данные из global view (или venue_profiles)
        if (data) {
             // Нормализуем данные, если нужно
             setAllItems(data);
        }
    }
    
    setLoading(false);
  }

  function applyFilters() {
      let result = [...allItems];

      // 1. Фильтр по городу
      if (selectedCity) {
          result = result.filter(item => item.city === selectedCity);
      }

      // 2. Сортировка
      if (sortBy === 'price_asc') {
          result.sort((a, b) => (a.price_start || 0) - (b.price_start || 0));
      } else if (sortBy === 'price_desc') {
          result.sort((a, b) => (b.price_start || 0) - (a.price_start || 0));
      } else if (sortBy === 'rating') {
          result.sort((a, b) => (b.avg_rating || 0) - (a.avg_rating || 0));
      }

      setFilteredItems(result);
  }

  // Компонент Чипса Фильтра
  const FilterChip = ({ label, active, icon, onPress }: any) => (
      <TouchableOpacity 
        onPress={onPress}
        style={[
            styles.chip, 
            { backgroundColor: active ? theme.colors.black : theme.colors.grey0, borderColor: theme.colors.grey1 }
        ]}
      >
          {icon && <Icon name={icon} type="feather" size={14} color={active ? '#fff' : theme.colors.black} style={{ marginRight: 6 }} />}
          <Text style={{ color: active ? '#fff' : theme.colors.black, fontWeight: '600', fontSize: 13 }}>{label}</Text>
          {active && <Icon name="x" type="feather" size={14} color="#fff" style={{ marginLeft: 6 }} />}
      </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <AppHeader title={name as string} />
      
      {/* ПАНЕЛЬ ФИЛЬТРОВ */}
      <View style={styles.filterContainer}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 20 }}>
              
              {/* Фильтр Города */}
              <FilterChip 
                label={selectedCity || 'Все города'} 
                active={!!selectedCity} 
                icon="map-pin"
                onPress={() => setSelectedCity(selectedCity ? null : userCity || 'Алматы')} 
              />

              {/* Фильтр Сортировки */}
              <FilterChip 
                label={sortBy === 'default' ? 'Сортировка' : sortBy === 'price_asc' ? 'Сначала дешевые' : sortBy === 'price_desc' ? 'Сначала дорогие' : 'По рейтингу'} 
                active={sortBy !== 'default'}
                icon="sliders"
                onPress={() => setModalVisible(true)}
              />

          </ScrollView>
      </View>
      
      {loading ? (
        <ActivityIndicator style={{ marginTop: 50 }} color={theme.colors.primary} size="large" />
      ) : (
        <FlatList
            data={filteredItems}
            keyExtractor={item => item.id.toString()}
            renderItem={({ item }) => <ProfileCard item={item} type={type as any} />}
            contentContainerStyle={{ padding: 20 }}
            ListEmptyComponent={
                <View style={{ alignItems: 'center', marginTop: 50 }}>
                     <Text style={{ fontSize: 40 }}>🔎</Text>
                     <Text style={{ color: theme.colors.grey2, marginTop: 10 }}>Никого не найдено по фильтрам</Text>
                     <TouchableOpacity onPress={() => { setSelectedCity(null); setSortBy('default'); }} style={{ marginTop: 20 }}>
                         <Text style={{ color: theme.colors.primary, fontWeight: 'bold' }}>Сбросить фильтры</Text>
                     </TouchableOpacity>
                </View>
            }
        />
      )}

      {/* МОДАЛКА СОРТИРОВКИ */}
      <Modal visible={modalVisible} transparent animationType="slide">
          <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setModalVisible(false)}>
              <View style={[styles.modalContent, { backgroundColor: theme.colors.background, paddingBottom: insets.bottom + 20 }]}>
                  <Text style={[styles.modalTitle, { color: theme.colors.black }]}>Сортировка</Text>
                  
                  {[
                      { label: 'По умолчанию', value: 'default' },
                      { label: 'Сначала дешевые', value: 'price_asc' },
                      { label: 'Сначала дорогие', value: 'price_desc' },
                      { label: 'Сначала высокий рейтинг', value: 'rating' },
                  ].map((opt) => (
                      <TouchableOpacity 
                        key={opt.value} 
                        style={[styles.sortItem, { borderBottomColor: theme.colors.grey1 }]}
                        onPress={() => { setSortBy(opt.value as SortType); setModalVisible(false); }}
                      >
                          <Text style={{ fontSize: 16, color: sortBy === opt.value ? theme.colors.primary : theme.colors.black, fontWeight: sortBy === opt.value ? 'bold' : '400' }}>
                              {opt.label}
                          </Text>
                          {sortBy === opt.value && <Icon name="check" type="feather" color={theme.colors.primary} />}
                      </TouchableOpacity>
                  ))}
              </View>
          </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 50 },
  filterContainer: { height: 50, justifyContent: 'center' },
  chip: { 
      flexDirection: 'row', alignItems: 'center', 
      paddingHorizontal: 14, paddingVertical: 8, 
      borderRadius: 20, borderWidth: 1 
  },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 25, borderTopRightRadius: 25, padding: 25 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  sortItem: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 15, borderBottomWidth: 1 }
});