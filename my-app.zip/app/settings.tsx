import { Text, Button, Icon, Input, Switch, useTheme, useThemeMode } from '@rneui/themed';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { AppHeader } from '../components/AppHeader';
import { UserAvatar } from '../components/UserAvatar';
import { supabase } from '../lib/supabase';
import { uploadFileToSupabase } from '../lib/uploader';
import { useAuth } from '../providers/AuthProvider';

// Компонент пункта меню
const SettingItem = ({ icon, title, type = 'none', value, onPress, color, theme }: any) => (
  <TouchableOpacity 
    onPress={onPress} 
    activeOpacity={0.7}
    style={[styles.itemContainer, { backgroundColor: theme.colors.grey0 }]}
  >
      <View style={[styles.iconBox, { backgroundColor: theme.colors.grey1 }]}>
          <Icon name={icon} type="feather" size={18} color={color || theme.colors.black} />
      </View>
      <Text style={[styles.itemText, { color: color || theme.colors.black }]}>{title}</Text>
      {type === 'switch' ? (
          <Switch value={value} onValueChange={onPress} trackColor={{true: theme.colors.primary}} thumbColor="#fff" />
      ) : (
          type === 'arrow' && <Icon name="chevron-right" type="feather" color={theme.colors.grey2} size={20} />
      )}
  </TouchableOpacity>
);

export default function SettingsScreen() {
  const { user, isLoading: authLoading } = useAuth();
  const { theme } = useTheme();
  const { mode, setMode } = useThemeMode();
  
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (user) fetchProfile();
  }, [user]);

  async function fetchProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', user?.id).single();
    if (data) {
      setProfile(data);
      setFullName(data.full_name || '');
      setPhone(data.phone || '');
    }
  }

  async function pickImage() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.5,
    });

    if (!result.canceled && result.assets[0].uri) {
      setLoading(true);
      try {
        const fileExt = 'jpg';
        const fileName = `${user?.id}/avatar_${Date.now()}.${fileExt}`;
        const publicUrl = await uploadFileToSupabase('avatars', result.assets[0].uri, fileName);
        
        const { error } = await supabase.from('profiles').update({ avatar_url: publicUrl }).eq('id', user?.id);
        if (error) throw error;
        
        setProfile({ ...profile, avatar_url: publicUrl });
        Alert.alert("Успешно", "Ваше фото обновлено");
      } catch (e: any) {
        Alert.alert("Ошибка загрузки", e.message);
      } finally {
        setLoading(false);
      }
    }
  }

  async function handleSave() {
    setLoading(true);
    const { error } = await supabase.from('profiles').update({ full_name: fullName, phone: phone }).eq('id', user?.id);
    setLoading(false);
    if (error) Alert.alert("Ошибка", error.message);
    else Alert.alert("Сохранено", "Данные профиля обновлены");
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    router.replace('/(auth)/login');
  }

  // ФУНКЦИЯ УДАЛЕНИЯ АККАУНТА
  const handleDeleteAccount = () => {
    Alert.alert(
        "Удалить аккаунт?",
        "Это действие необратимо. Все ваши данные (заказы, чаты, профиль) будут стерты навсегда.",
        [
            { text: "Отмена", style: "cancel" },
            { 
                text: "Удалить навсегда", 
                style: "destructive", 
                onPress: async () => {
                    setLoading(true);
                    // Вызываем RPC функцию из базы данных
                    const { error } = await supabase.rpc('delete_own_account');
                    
                    if (error) {
                        Alert.alert("Ошибка", "Не удалось удалить аккаунт: " + error.message);
                        setLoading(false);
                    } else {
                        // После удаления из БД, выходим из сессии
                        await supabase.auth.signOut();
                        router.replace('/(auth)/login');
                    }
                }
            }
        ]
    );
  };

  if (authLoading) return <View style={styles.center}><ActivityIndicator size="large" color={theme.colors.primary} /></View>;

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{flex: 1, backgroundColor: theme.colors.background}}>
      <AppHeader title="Настройки" />
      
      <ScrollView contentContainerStyle={styles.container}>
        
        {/* АВАТАР */}
        <View style={styles.avatarSection}>
            <TouchableOpacity onPress={pickImage} style={styles.avatarWrapper}>
                <UserAvatar avatarUrl={profile?.avatar_url} size={110} />
                <View style={[styles.editBadge, { backgroundColor: theme.colors.primary, borderColor: theme.colors.background }]}>
                    <Icon name="camera" type="feather" size={14} color="#fff" />
                </View>
            </TouchableOpacity>
            <Text h4 style={{ marginTop: 16, color: theme.colors.black, fontWeight: '800' }}>
                {fullName || 'Без имени'}
            </Text>
            <Text style={{ color: theme.colors.grey2 }}>{user?.email}</Text>
        </View>

        {/* ФОРМА */}
        <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.colors.grey2 }]}>ЛИЧНЫЕ ДАННЫЕ</Text>
            <Input 
                value={fullName} onChangeText={setFullName} placeholder="Ваше имя"
                leftIcon={<Icon name="user" type="feather" size={18} color={theme.colors.grey2} />}
            />
            <Input 
                value={phone} onChangeText={setPhone} placeholder="Телефон" keyboardType="phone-pad"
                leftIcon={<Icon name="phone" type="feather" size={18} color={theme.colors.grey2} />}
            />
             <Button title="Сохранить изменения" loading={loading} onPress={handleSave} />
        </View>

        {/* НАСТРОЙКИ */}
        <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.colors.grey2 }]}>ПРИЛОЖЕНИЕ</Text>
            
            <SettingItem 
                icon="moon" title="Темная тема" type="switch"
                value={mode === 'dark'} onPress={(val: boolean) => setMode(val ? 'dark' : 'light')} 
                theme={theme}
            />
            
            <SettingItem 
                icon="info" title="О приложении" type="arrow" 
                onPress={() => router.push('/credits')} 
                theme={theme}
            />

            {profile?.is_admin && (
                 <SettingItem icon="shield" title="Админ Панель" type="arrow" onPress={() => router.push('/(admin)/dashboard')} color={theme.colors.primary} theme={theme} />
            )}
        </View>

        {/* ЗОНА ОПАСНОСТИ */}
        <View style={[styles.section, { marginBottom: 40 }]}>
            <Text style={[styles.sectionTitle, { color: theme.colors.error }]}>ЗОНА ОПАСНОСТИ</Text>
            
            <SettingItem 
                icon="log-out" title="Выйти из аккаунта" 
                onPress={handleSignOut} 
                theme={theme} 
            />
            
            {/* КНОПКА УДАЛЕНИЯ */}
            <SettingItem 
                icon="trash-2" title="Удалить аккаунт" 
                onPress={handleDeleteAccount} 
                color={theme.colors.error} 
                theme={theme} 
            />
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  container: { padding: 20 },
  avatarSection: { alignItems: 'center', marginBottom: 30 },
  avatarWrapper: { position: 'relative' },
  editBadge: { position: 'absolute', bottom: 0, right: 0, padding: 8, borderRadius: 20, borderWidth: 3 },
  section: { marginBottom: 25 },
  sectionTitle: { fontSize: 12, fontWeight: '700', marginBottom: 10, marginLeft: 5, textTransform: 'uppercase' },
  
  itemContainer: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 16, marginBottom: 10 },
  iconBox: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  itemText: { fontSize: 16, fontWeight: '600', flex: 1 },
});