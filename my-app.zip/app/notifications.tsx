import { Icon, Text, useTheme } from '@rneui/themed';
import { useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, View } from 'react-native';
import { AppHeader } from '../components/AppHeader';
import { supabase } from '../lib/supabase';
import { useAuth } from '../providers/AuthProvider';

export default function NotificationsScreen() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      fetchNotifications();
    }, [])
  );

  async function fetchNotifications() {
    if (!user) return;
    
    const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);
        
    if (data) {
        setItems(data);
        // Помечаем прочитанными
        const unreadIds = data.filter(n => !n.is_read).map(n => n.id);
        if (unreadIds.length > 0) {
            await supabase.from('notifications').update({ is_read: true }).in('id', unreadIds);
        }
    }
    setLoading(false);
    setRefreshing(false);
  }

  const getIconInfo = (title: string) => {
      const t = title?.toLowerCase() || '';
      if (t.includes('сообщение')) return { name: 'message-circle', color: '#fff', bg: '#2089dc' }; // Blue
      if (t.includes('подтверждена') || t.includes('заказ')) return { name: 'check-circle', color: '#fff', bg: '#10B981' }; // Green
      if (t.includes('отменено') || t.includes('нет мест')) return { name: 'x-circle', color: '#fff', bg: theme.colors.error }; // Red
      return { name: 'bell', color: '#fff', bg: '#F59E0B' }; // Orange
  };

  const renderItem = ({ item }: { item: any }) => {
      const iconInfo = getIconInfo(item.title);
      return (
        <View style={[styles.item, { backgroundColor: theme.colors.grey0, opacity: item.is_read ? 0.7 : 1 }]}>
            <View style={[styles.iconBox, { backgroundColor: iconInfo.bg }]}>
                <Icon name={iconInfo.name} type="feather" size={20} color={iconInfo.color} />
            </View>
            <View style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={[styles.title, { color: theme.colors.black }]}>{item.title}</Text>
                    {!item.is_read && <View style={styles.dot} />}
                </View>
                <Text style={[styles.body, { color: theme.colors.black }]} numberOfLines={2}>{item.body}</Text>
                <Text style={styles.date}>
                    {new Date(item.created_at).toLocaleString('ru-RU', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </Text>
            </View>
        </View>
      );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <AppHeader title="Уведомления" />

      {loading && !refreshing ? (
        <ActivityIndicator size="large" color={theme.colors.primary} style={{ marginTop: 50 }} />
      ) : (
        <FlatList
            data={items}
            keyExtractor={item => item.id}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchNotifications(); }} tintColor={theme.colors.primary} />}
            ListEmptyComponent={
                <View style={styles.empty}>
                    <Icon name="bell-off" type="feather" size={60} color={theme.colors.grey2} />
                    <Text style={{ color: theme.colors.grey2, marginTop: 15, fontSize: 16 }}>Уведомлений нет</Text>
                </View>
            }
            renderItem={renderItem}
            contentContainerStyle={{ padding: 20 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
    container: { flex: 1, paddingTop: 40 },
    item: { flexDirection: 'row', padding: 16, borderRadius: 20, marginBottom: 12 },
    iconBox: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
    title: { fontSize: 16, fontWeight: '700', marginBottom: 4 },
    body: { fontSize: 14, lineHeight: 20, opacity: 0.8 },
    date: { fontSize: 11, color: 'gray', marginTop: 6 },
    dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#EF4444' },
    empty: { alignItems: 'center', marginTop: 100 },
});