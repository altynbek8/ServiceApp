import { Icon, Text, useTheme } from '@rneui/themed';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { ActivityIndicator, Alert, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';

export default function RoleSelectScreen() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  async function selectRole(role: 'client' | 'specialist' | 'venue') {
    if (!user) return;
    setLoading(true);
    
    // upsert создаст или обновит
    const { error } = await supabase.from('profiles').upsert({ id: user.id, role: role });

    if (error) {
        Alert.alert('Ошибка', error.message);
        setLoading(false);
    } else {
        // Небольшая задержка для обновления сессии
        setTimeout(() => router.replace('/'), 500);
    }
  }

  const RoleCard = ({ title, icon, desc, role, color }: any) => (
    <TouchableOpacity 
        activeOpacity={0.9} 
        onPress={() => selectRole(role)}
        style={[styles.card, { backgroundColor: theme.colors.grey0 }]}
    >
      <View style={[styles.iconBox, { backgroundColor: color + '20' }]}>
        <Icon name={icon} type="feather" size={32} color={color} />
      </View>
      <View style={{ flex: 1 }}>
          <Text h4 style={{ fontSize: 18, fontWeight: '800', color: theme.colors.black, marginBottom: 4 }}>{title}</Text>
          <Text style={{ color: theme.colors.grey2, lineHeight: 20 }}>{desc}</Text>
      </View>
      <Icon name="chevron-right" type="feather" color={theme.colors.grey2} />
    </TouchableOpacity>
  );

  if (loading) return (
      <View style={[styles.center, { backgroundColor: theme.colors.background }]}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <Text style={{ marginTop: 20, color: theme.colors.grey2 }}>Настраиваем профиль...</Text>
      </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
          <Text h2 style={{ color: theme.colors.black, textAlign: 'center', fontWeight: '900' }}>Кто вы?</Text>
          <Text style={{ textAlign: 'center', color: theme.colors.grey2, marginTop: 10, fontSize: 16 }}>
              Выберите роль, чтобы мы настроили приложение под вас
          </Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
          <RoleCard 
            title="Я Клиент" 
            role="client"
            icon="search" 
            color="#6366F1" // Indigo
            desc="Хочу искать мастеров, записываться на услуги и бронировать места." 
          />
          
          <RoleCard 
            title="Я Специалист" 
            role="specialist"
            icon="briefcase" 
            color="#F59E0B" // Amber
            desc="Хочу предлагать услуги, вести запись клиентов и портфолио." 
          />
          
          <RoleCard 
            title="Я Заведение" 
            role="venue"
            icon="coffee" 
            color="#10B981" // Emerald
            desc="Владею рестораном, салоном или студией. Хочу управлять бронями." 
          />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { paddingHorizontal: 30, paddingTop: 40, paddingBottom: 20 },
  content: { padding: 20 },
  card: { 
      flexDirection: 'row', alignItems: 'center', 
      padding: 20, marginBottom: 16, borderRadius: 24,
      shadowColor: "#000", shadowOffset: {width: 0, height: 4}, shadowOpacity: 0.05, shadowRadius: 10, elevation: 3
  },
  iconBox: { width: 60, height: 60, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginRight: 15 }
});