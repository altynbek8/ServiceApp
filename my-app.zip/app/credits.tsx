import { Icon, Text, useTheme } from '@rneui/themed';
import { router } from 'expo-router';
import React from 'react';
import { ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader } from '../components/AppHeader';

export default function CreditsScreen() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background, paddingTop: insets.top }]}>
      <AppHeader title="О приложении" />

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.logoSection}>
            <View style={[styles.logoBox, { backgroundColor: theme.colors.primary }]}>
                <Icon name="zap" type="feather" color="#fff" size={40} />
            </View>
            <Text h3 style={{ color: theme.colors.black, marginTop: 20, fontWeight: '900' }}>ServiceApp</Text>
            <Text style={styles.version}>Версия 1.0.0 (Beta)</Text>
        </View>

        <View style={[styles.card, { backgroundColor: theme.colors.grey0 }]}>
            <Text style={styles.label}>Разработчик</Text>
            <Text style={[styles.name, { color: theme.colors.primary }]}>Altynbek Temirkhan</Text>
            <Text style={[styles.subText, { color: theme.colors.black }]}>Full Stack Engineer</Text>
        </View>

        <View style={[styles.card, { backgroundColor: theme.colors.grey0 }]}>
            <Text style={styles.label}>Стек технологий</Text>
            <View style={styles.stackRow}><Text style={styles.chip}>React Native</Text><Text style={styles.chip}>Expo</Text></View>
            <View style={styles.stackRow}><Text style={styles.chip}>Supabase</Text><Text style={styles.chip}>PostgreSQL</Text></View>
            <View style={styles.stackRow}><Text style={styles.chip}>TypeScript</Text></View>
        </View>

        <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 30 }}>
            <Text style={{ color: theme.colors.grey2, textAlign: 'center' }}>Сделано с любовью и дисциплиной</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: 30, alignItems: 'center' },
  logoSection: { alignItems: 'center', marginBottom: 40 },
  logoBox: { width: 80, height: 80, borderRadius: 25, justifyContent: 'center', alignItems: 'center', transform: [{ rotate: '-10deg' }] },
  version: { color: 'gray', marginTop: 5, fontWeight: '600' },
  
  card: { width: '100%', padding: 20, borderRadius: 20, alignItems: 'center', marginBottom: 20 },
  label: { fontSize: 12, color: 'gray', textTransform: 'uppercase', fontWeight: 'bold', marginBottom: 10 },
  name: { fontSize: 24, fontWeight: '900' },
  subText: { fontSize: 16, marginTop: 2 },
  
  stackRow: { flexDirection: 'row', gap: 10, marginBottom: 8 },
  chip: { backgroundColor: '#f1f3f5', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, fontSize: 12, fontWeight: '600', color: '#333' }
});