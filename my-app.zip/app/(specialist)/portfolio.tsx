import { Icon, useTheme } from '@rneui/themed';
import * as ImagePicker from 'expo-image-picker';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  FlatList,
  Image,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader } from '../../components/AppHeader';
import { supabase } from '../../lib/supabase';
import { uploadFileToSupabase } from '../../lib/uploader';
import { useAuth } from '../../providers/AuthProvider';

const { width } = Dimensions.get('window');
// Расчет размера: (Экран - (отступы * количество)) / 3 колонки
const COLUMN_SIZE = (width - 40) / 3; 

export default function MyPortfolioScreen() {
  const { user } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => { fetchPortfolio(); }, []);

  async function fetchPortfolio() {
    if (!user) return;
    const { data } = await supabase
        .from('portfolio')
        .select('*')
        .eq('specialist_id', user.id)
        .order('created_at', { ascending: false });
    
    if (data) setItems(data);
    setLoading(false);
  }

  async function pickMedia() {
    const result = await ImagePicker.launchImageLibraryAsync({ 
        mediaTypes: ImagePicker.MediaTypeOptions.Images, // Пока только фото для простоты
        allowsEditing: true, 
        quality: 0.7 
    });
    if (!result.canceled) uploadFile(result.assets[0]);
  }

  async function uploadFile(asset: any) {
    setUploading(true);
    try {
      const ext = asset.uri.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `${user?.id}/${Date.now()}.${ext}`;
      const publicUrl = await uploadFileToSupabase('portfolio', asset.uri, fileName);
      
      const { error } = await supabase.from('portfolio').insert({ 
          specialist_id: user?.id, 
          file_url: publicUrl, 
          file_type: 'image' 
      });
      
      if (error) throw error;
      fetchPortfolio();
    } catch (e: any) { 
        Alert.alert('Ошибка', e.message); 
    } finally { 
        setUploading(false); 
    }
  }

  async function deleteItem(id: string) {
    Alert.alert("Удалить?", "Это фото пропадет из вашего профиля", [
        { text: "Отмена", style: "cancel" },
        { text: "Удалить", style: "destructive", onPress: async () => {
            await supabase.from('portfolio').delete().eq('id', id);
            setItems(prev => prev.filter(item => item.id !== id));
        }}
    ]);
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background, paddingTop: insets.top }]}>
      <AppHeader 
        title="Мое портфолио" 
        rightComponent={
          <TouchableOpacity 
            onPress={pickMedia} 
            disabled={uploading}
            style={styles.addBtn}
          >
            {uploading ? (
              <ActivityIndicator size="small" color={theme.colors.primary} />
            ) : (
              <Icon name="plus" type="feather" color={theme.colors.primary} size={24} />
            )}
          </TouchableOpacity>
        } 
      />

      {loading ? <ActivityIndicator size="large" color={theme.colors.primary} style={{marginTop: 50}} /> : (
          <FlatList 
            data={items} 
            keyExtractor={item => item.id} 
            numColumns={3} 
            contentContainerStyle={styles.gridContainer}
            columnWrapperStyle={{ gap: 10 }}
            renderItem={({item}) => (
                <View style={styles.gridItemWrapper}>
                    <TouchableOpacity 
                        style={styles.gridItem} 
                        onPress={() => setSelectedImage(item.file_url)}
                        activeOpacity={0.8}
                    >
                        <Image source={{ uri: item.file_url }} style={styles.media} />
                    </TouchableOpacity>
                    
                    <TouchableOpacity style={styles.deleteBtn} onPress={() => deleteItem(item.id)}>
                        <Icon name="x" type="feather" color="white" size={12} />
                    </TouchableOpacity>
                </View>
            )} 
            ListEmptyComponent={
                <View style={styles.empty}>
                    <Icon name="image" type="feather" size={60} color={theme.colors.grey2} />
                    <Text style={{color: theme.colors.grey2, marginTop: 15}}>Нет загруженных работ</Text>
                </View>
            }
          />
      )}

      {/* FULL SCREEN MODAL */}
      <Modal visible={!!selectedImage} transparent animationType="fade">
          <View style={styles.modalBg}>
              <TouchableOpacity style={[styles.closeModal, { top: insets.top + 20 }]} onPress={() => setSelectedImage(null)}>
                  <Icon name="x" type="feather" color="white" size={32} />
              </TouchableOpacity>
              {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImg} resizeMode="contain" />}
          </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  addBtn: { padding: 5 },
  gridContainer: { padding: 20, gap: 10 },
  gridItemWrapper: { position: 'relative', width: COLUMN_SIZE, height: COLUMN_SIZE * 1.3, marginBottom: 10 },
  gridItem: { flex: 1, borderRadius: 12, overflow: 'hidden', backgroundColor: '#eee' },
  media: { width: '100%', height: '100%' },
  
  deleteBtn: { 
      position: 'absolute', top: 6, right: 6, 
      backgroundColor: 'rgba(0,0,0,0.6)', 
      width: 24, height: 24, borderRadius: 12, 
      justifyContent: 'center', alignItems: 'center' 
  },
  
  modalBg: { flex: 1, backgroundColor: 'black', justifyContent: 'center' },
  closeModal: { position: 'absolute', right: 20, zIndex: 10 },
  fullImg: { width: '100%', height: '100%' },
  empty: { alignItems: 'center', marginTop: 100 }
});