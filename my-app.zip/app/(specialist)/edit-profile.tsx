import { Button, Icon, Input, Text, useTheme } from '@rneui/themed';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { UserAvatar } from '../../components/UserAvatar'; // <---
import { supabase } from '../../lib/supabase';
import { uploadFileToSupabase } from '../../lib/uploader';
import { useAuth } from '../../providers/AuthProvider';

export default function EditProfileScreen() {
  const { user, isLoading: authLoading } = useAuth();
  const { theme } = useTheme();
  
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);
  
  const [bio, setBio] = useState('');
  const [experience, setExperience] = useState('');
  const [price, setPrice] = useState('');
  const [categories, setCategories] = useState<{id: number, name: string}[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  useEffect(() => { if (!authLoading && user) loadData(); }, [authLoading, user]);

  async function loadData() {
    try {
      const { data: catData } = await supabase.from('categories').select('id, name').eq('type', 'specialist');
      if (catData) setCategories(catData);
      
      if (!user) return;
      const { data: profile } = await supabase.from('specialist_profiles').select('*').eq('id', user.id).single();
      if (profile) { 
          setBio(profile.bio || ''); 
          setExperience(profile.experience_years?.toString() || ''); 
          setPrice(profile.price_start?.toString() || ''); 
          setSelectedCategory(profile.category_id); 
      }
      const { data: mainProfile } = await supabase.from('profiles').select('avatar_url').eq('id', user.id).single();
      if (mainProfile) setAvatarUrl(mainProfile.avatar_url);
    } catch (e) { console.log(e); } finally { setFetching(false); }
  }

  async function pickAvatar() {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.5 });
    if (!result.canceled) {
        setLoading(true);
        const fileName = `${user?.id}/avatar_${Date.now()}.jpg`;
        const publicUrl = await uploadFileToSupabase('avatars', result.assets[0].uri, fileName);
        await supabase.from('profiles').update({ avatar_url: publicUrl }).eq('id', user?.id);
        setAvatarUrl(publicUrl);
        setLoading(false);
    }
  }

  async function saveProfile() {
    if (!user) return;
    setLoading(true);
    const updates = { id: user.id, bio, experience_years: parseInt(experience) || 0, price_start: parseInt(price) || 0, category_id: selectedCategory };
    const { error } = await supabase.from('specialist_profiles').upsert(updates);
    setLoading(false);
    if (error) Alert.alert('Ошибка', error.message);
    else { Alert.alert('Успех', 'Сохранено!'); router.back(); }
  }

  if (authLoading || fetching) return <View style={styles.center}><ActivityIndicator size="large" color={theme.colors.primary} /></View>;

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <ScrollView contentContainerStyle={styles.container}>
        
        {/* Хедер с кнопкой назад */}
        <View style={styles.header}>
           <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
               <Icon name="arrow-left" type="feather" color={theme.colors.black} />
           </TouchableOpacity>
           <Text h4 style={{ color: theme.colors.black }}>Анкета</Text>
           <View style={{ width: 40 }} />
        </View>

        {/* Аватар */}
        <TouchableOpacity onPress={pickAvatar} style={styles.avatarSection}>
            <UserAvatar avatarUrl={avatarUrl} size={100} />
            <Text style={{ color: theme.colors.primary, marginTop: 10, fontWeight: '600' }}>Изменить фото</Text>
        </TouchableOpacity>

        {/* Категории (Chips) */}
        <Text style={[styles.label, {color: theme.colors.grey2}]}>СПЕЦИАЛИЗАЦИЯ</Text>
        <View style={styles.catContainer}>
          {categories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <TouchableOpacity 
                    key={cat.id} 
                    onPress={() => setSelectedCategory(cat.id)}
                    style={[
                        styles.chip, 
                        isActive ? { backgroundColor: theme.colors.primary } : { backgroundColor: theme.colors.grey0, borderWidth: 1, borderColor: theme.colors.grey1 }
                    ]}
                >
                    <Text style={[styles.chipText, { color: isActive ? '#fff' : theme.colors.black }]}>{cat.name}</Text>
                </TouchableOpacity>
              )
          })}
        </View>

        {/* Инпуты */}
        <View style={styles.form}>
            <Input 
                label="О себе (био)" 
                placeholder="Расскажите о своих навыках..."
                multiline numberOfLines={3} 
                value={bio} onChangeText={setBio} 
                inputStyle={{ height: 80, textAlignVertical: 'top', paddingTop: 10 }} // Фикс для мультилайн
            />
            
            <View style={styles.row}>
                <View style={{flex: 1, marginRight: 10}}>
                    <Input 
                        label="Опыт (лет)" placeholder="3" 
                        keyboardType="numeric" 
                        value={experience} onChangeText={setExperience} 
                    />
                </View>
                <View style={{flex: 1}}>
                    <Input 
                        label="Цена от (₸)" placeholder="5000" 
                        keyboardType="numeric" 
                        value={price} onChangeText={setPrice} 
                    />
                </View>
            </View>

            <Button title="Сохранить анкету" onPress={saveProfile} loading={loading} containerStyle={{ marginTop: 20 }} />
        </View>
        
        <View style={{height: 50}} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  container: { padding: 20, paddingTop: 50 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 30 },
  backBtn: { padding: 10 },
  avatarSection: { alignItems: 'center', marginBottom: 30 },
  label: { fontSize: 12, fontWeight: '700', marginLeft: 5, marginBottom: 10, textTransform: 'uppercase' },
  
  catContainer: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 30, gap: 10 },
  chip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20 },
  chipText: { fontWeight: '600', fontSize: 14 },
  
  form: { gap: 5 },
  row: { flexDirection: 'row' }
});