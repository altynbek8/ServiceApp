import { CheckBox, Text, useTheme } from '@rneui/themed';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, View } from 'react-native';
import { Calendar, LocaleConfig } from 'react-native-calendars';
import { AppHeader } from '../../components/AppHeader';
import { UserAvatar } from '../../components/UserAvatar'; // <---
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';

// Настройка русского языка для календаря
LocaleConfig.locales['ru'] = {
  monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
  monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'],
  dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
  dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
  today: 'Сегодня'
};
LocaleConfig.defaultLocale = 'ru';

export default function SpecialistScheduleScreen() {
  const { theme } = useTheme();
  const { user } = useAuth();
  
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [busyDates, setBusyDates] = useState<any>({});
  const [dayBookings, setDayBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { fetchScheduleData(); }, [selectedDate]);

  async function fetchScheduleData() {
    if (!user) return;
    setLoading(true);
    
    // 1. Грузим выходные
    const { data: busy } = await supabase.from('busy_dates').select('date').eq('specialist_id', user.id);
    const marks: any = {};
    busy?.forEach(d => { 
        marks[d.date] = { marked: true, dotColor: theme.colors.error }; 
    });
    
    // Добавляем выделение выбранной даты
    marks[selectedDate] = { 
        ...marks[selectedDate], 
        selected: true, 
        selectedColor: theme.colors.primary,
        selectedTextColor: '#fff'
    };
    setBusyDates(marks);

    // 2. Грузим записи на этот день
    const { data: bookings } = await supabase
        .from('bookings')
        .select('*, client:profiles!client_id(full_name, avatar_url)')
        .eq('specialist_id', user.id)
        .ilike('date_time', `${selectedDate}%`)
        .order('date_time');
        
    setDayBookings(bookings || []);
    setLoading(false);
  }

  async function toggleFullDay() {
    const isBusy = !!busyDates[selectedDate]?.marked;
    if (isBusy) {
        await supabase.from('busy_dates').delete().eq('specialist_id', user?.id).eq('date', selectedDate);
    } else {
        await supabase.from('busy_dates').insert({ specialist_id: user?.id, date: selectedDate });
    }
    fetchScheduleData();
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <AppHeader title="Моё расписание" showBack={false} />
      
      <View style={styles.calendarWrapper}>
          <Calendar 
            onDayPress={(day: any) => setSelectedDate(day.dateString)}
            markedDates={busyDates}
            theme={{ 
                calendarBackground: 'transparent', 
                dayTextColor: theme.colors.black, 
                monthTextColor: theme.colors.black, 
                arrowColor: theme.colors.primary,
                todayTextColor: theme.colors.primary,
                textDayFontWeight: '600',
                textMonthFontWeight: 'bold',
            }}
          />
      </View>

      <View style={styles.controls}>
          <CheckBox 
            title={busyDates[selectedDate]?.marked ? "Этот день отмечен как выходной" : "Сделать выходным"} 
            checked={!!busyDates[selectedDate]?.marked} 
            onPress={toggleFullDay} 
            checkedColor={theme.colors.error}
            containerStyle={{ backgroundColor: 'transparent', borderWidth: 0, padding: 0 }} 
            textStyle={{ color: theme.colors.black, fontWeight: '600' }} 
          />
      </View>

      <View style={[styles.listContainer, { backgroundColor: theme.colors.background }]}>
          <Text style={[styles.listTitle, { color: theme.colors.grey2 }]}>ЗАПИСИ НА {selectedDate.split('-').reverse().join('.')}</Text>
          
          {loading ? <ActivityIndicator color={theme.colors.primary} style={{ marginTop: 20 }} /> : (
              <FlatList
                data={dayBookings}
                keyExtractor={item => item.id}
                contentContainerStyle={{ paddingBottom: 20 }}
                renderItem={({ item }) => (
                    <View style={[styles.card, { backgroundColor: theme.colors.grey0 }]}>
                        <View style={styles.timeBox}>
                            <Text style={{ fontSize: 16, fontWeight: '900', color: theme.colors.primary }}>
                                {item.date_time.split(' ')[1]}
                            </Text>
                        </View>
                        
                        <View style={styles.clientInfo}>
                             <UserAvatar avatarUrl={item.client?.avatar_url} size={40} />
                             <View style={{ marginLeft: 10 }}>
                                 <Text style={{ fontWeight: 'bold', color: theme.colors.black }}>{item.client?.full_name}</Text>
                                 <Text style={{ fontSize: 12, color: 'gray' }}>{item.status === 'confirmed' ? 'Подтверждено' : item.status}</Text>
                             </View>
                        </View>
                    </View>
                )}
                ListEmptyComponent={
                    <View style={styles.empty}>
                        <Text style={{ color: theme.colors.grey2 }}>Нет записей на этот день</Text>
                    </View>
                }
              />
          )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 50 },
  calendarWrapper: { paddingHorizontal: 10, marginBottom: 10 },
  controls: { paddingHorizontal: 15, marginBottom: 10 },
  listContainer: { flex: 1, paddingHorizontal: 20, paddingTop: 20, borderTopLeftRadius: 30, borderTopRightRadius: 30, elevation: 10, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10 },
  listTitle: { fontSize: 12, fontWeight: 'bold', marginBottom: 15 },
  
  card: { flexDirection: 'row', alignItems: 'center', padding: 15, borderRadius: 16, marginBottom: 10 },
  timeBox: { paddingRight: 15, borderRightWidth: 1, borderRightColor: '#eee', marginRight: 15 },
  clientInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  empty: { alignItems: 'center', marginTop: 30 }
});