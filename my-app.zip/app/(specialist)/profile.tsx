import { Icon, Text, useTheme } from '@rneui/themed';
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { UserAvatar } from '../../components/UserAvatar'; // <--- Наш компонент
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';

export default function SpecialistProfileScreen() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);

  useFocusEffect(
    useCallback(() => {
      if (user) {
        supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single()
          .then(({ data }) => setProfile(data));
      }
    }, [user])
  );

  const menuItems = [
    { title: 'Редактировать анкету', icon: 'edit-3', route: '/(specialist)/edit-profile', color: theme.colors.primary },
    { title: 'Мое портфолио', icon: 'image', route: '/(specialist)/portfolio', color: '#F59E0B' }, // Amber
    { title: 'Настройки аккаунта', icon: 'settings', route: '/settings', color: theme.colors.grey2 },
    { title: 'О приложении', icon: 'info', route: '/credits', color: '#10B981' }, // Emerald
  ];

  // Компонент одной строки меню
  const MenuItem = ({ item }: any) => (
    <TouchableOpacity 
      onPress={() => router.push(item.route)}
      activeOpacity={0.7}
      style={[styles.menuItem, { backgroundColor: theme.colors.grey0 }]}
    >
      <View style={[styles.iconBox, { backgroundColor: item.color + '15' }]}>
        <Icon name={item.icon} type="feather" color={item.color} size={20} />
      </View>
      <Text style={[styles.menuTitle, { color: theme.colors.black }]}>{item.title}</Text>
      <Icon name="chevron-right" type="feather" color={theme.colors.grey3} size={20} />
    </TouchableOpacity>
  );

  return (
    <ScrollView 
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      contentContainerStyle={{ paddingBottom: 40 }}
    >
      <View style={styles.header}>
        {/* АВАТАР */}
        <View style={styles.avatarContainer}>
             <UserAvatar avatarUrl={profile?.avatar_url} size={110} />
             <View style={[styles.roleBadge, { backgroundColor: theme.colors.primary }]}>
                <Icon name="briefcase" type="feather" size={12} color="#fff" />
                <Text style={styles.roleText}>Мастер</Text>
             </View>
        </View>

        <Text h3 style={{ color: theme.colors.black, marginTop: 16, fontWeight: '800' }}>
            {profile?.full_name || 'Мастер'}
        </Text>
        <Text style={{ color: theme.colors.grey2, marginTop: 4 }}>
            {profile?.city || 'Город не указан'}
        </Text>
        
        {/* КАРТОЧКА БАЛАНСА (Стиль банковской карты) */}
        <View style={[styles.balanceCard, { backgroundColor: theme.colors.black }]}>
            <View>
                <Text style={styles.balanceLabel}>Ваш баланс</Text>
                <Text style={styles.balanceValue}>{profile?.balance || 0} ₸</Text>
            </View>
            <View style={styles.balanceIcon}>
                <Icon name="trending-up" type="feather" color="#fff" size={24} />
            </View>
        </View>
      </View>

      {/* МЕНЮ */}
      <View style={styles.menuContainer}>
        {menuItems.map((item, i) => (
          <MenuItem key={i} item={item} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 20 },
  avatarContainer: { position: 'relative' },
  roleBadge: { 
      position: 'absolute', bottom: -5, alignSelf: 'center', 
      flexDirection: 'row', alignItems: 'center', 
      paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, gap: 4 
  },
  roleText: { color: '#fff', fontSize: 10, fontWeight: 'bold', textTransform: 'uppercase' },
  
  balanceCard: { 
      marginTop: 30, width: '100%', 
      borderRadius: 24, padding: 24, 
      flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
      shadowColor: "#000", shadowOffset: {width: 0, height: 10}, shadowOpacity: 0.1, shadowRadius: 20, elevation: 5
  },
  balanceLabel: { fontSize: 12, textTransform: 'uppercase', color: 'rgba(255,255,255,0.6)', fontWeight: 'bold', marginBottom: 4 },
  balanceValue: { fontSize: 28, fontWeight: '900', color: '#fff' },
  balanceIcon: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },

  menuContainer: { paddingHorizontal: 20, marginTop: 30, gap: 12 },
  menuItem: { 
      flexDirection: 'row', alignItems: 'center', 
      padding: 16, borderRadius: 18, 
  },
  iconBox: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  menuTitle: { flex: 1, fontSize: 16, fontWeight: '600' }
});