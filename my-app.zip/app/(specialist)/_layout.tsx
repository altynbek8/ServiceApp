import { Icon, useTheme } from '@rneui/themed';
import { Tabs } from 'expo-router';
import React from 'react';
import { Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
export default function SpecialistLayout() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  
  // ДОБАВЬ ЭТУ СТРОКУ НИЖЕ:
  const isDark = theme.mode === 'dark'; 

  return (
    <Tabs 
      screenOptions={{ 
        headerShown: false,
        tabBarStyle: { 
  backgroundColor: theme.colors.background,
  borderTopColor: isDark ? '#222' : '#eee',
  borderTopWidth: 1,

  // Убираем position: 'absolute' — это корень зла!
  
  // Правильный расчет высоты:
  // Если на Android есть insets.bottom (жесты), добавляем его. 
  // Если нет (кнопки), ставим фиксированную комфортную высоту.
  height: Platform.OS === 'android' 
    ? (insets.bottom > 0 ? 60 + insets.bottom : 65) 
    : 65 + insets.bottom,

  paddingBottom: Platform.OS === 'android' 
    ? (insets.bottom > 0 ? insets.bottom : 10) 
    : insets.bottom,
    
  elevation: 0, // Убираем лишние тени
},
        tabBarActiveTintColor: '#6366f1', 
        tabBarInactiveTintColor: 'gray', 
        tabBarShowLabel: false 
      }}
    >
      <Tabs.Screen name="home" options={{ tabBarIcon: ({ color }) => <Icon name="calendar-today" type="material" color={color} size={26} /> }} />
      <Tabs.Screen name="schedule" options={{ tabBarIcon: ({ color }) => <Icon name="history" type="material" color={color} size={26} /> }} />
      <Tabs.Screen name="messages" options={{ tabBarIcon: ({ color }) => <Icon name="chat" type="material" color={color} size={26} /> }} />
      <Tabs.Screen name="profile" options={{ tabBarIcon: ({ color }) => <Icon name="person" type="material" color={color} size={26} /> }} />
    </Tabs>
  );
}