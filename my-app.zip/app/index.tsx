import { Icon, Text, useTheme } from '@rneui/themed';
import { useRootNavigationState, useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../providers/AuthProvider';

export default function Index() {
  const { session, isLoading, user } = useAuth();
  const { theme } = useTheme();
  const router = useRouter();
  const rootNavigationState = useRootNavigationState();

  useEffect(() => {
    if (isLoading || !rootNavigationState?.key) return;

    if (!session) {
      // ИЗМЕНЕНИЕ: Ведем на онбординг вместо логина
      setTimeout(() => router.replace('/onboarding'), 500);
      return;
    }

    checkUserRole();
  }, [session, isLoading, rootNavigationState]);

  async function checkUserRole() {
    if (!user) return;
    
    // Проверяем профиль
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    // Если роли нет или профиль не создан — на выбор роли
    if (!profile || !profile.role) {
      router.replace('/(auth)/role-select');
      return;
    }

    // Роутинг по ролям
    if (profile.role === 'client' || profile.role === 'admin') router.replace('/(client)/home');
    else if (profile.role === 'specialist') router.replace('/(specialist)/home');
    else if (profile.role === 'venue') router.replace('/(venue)/home');
  }

  return (
    <View style={{ 
      flex: 1, 
      justifyContent: 'center', 
      alignItems: 'center', 
      backgroundColor: theme.colors.background // Используем цвет темы!
    }}>
      <StatusBar style={theme.mode === 'dark' ? "light" : "dark"} />
      
      {/* Логотип или Иконка пока грузится */}
      <View style={{ marginBottom: 20 }}>
        <Icon name="zap" type="feather" size={60} color={theme.colors.primary} />
      </View>
      
      <ActivityIndicator size="large" color={theme.colors.primary} />
      
      <Text style={{ 
          marginTop: 20, 
          color: theme.colors.grey2, 
          fontSize: 12, 
          fontWeight: '600',
          letterSpacing: 1 
      }}>
          ЗАГРУЗКА...
      </Text>
    </View>
  );
}