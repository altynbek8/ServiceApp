import { Button, Chip, Icon, Text, useTheme } from '@rneui/themed';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert,
  Dimensions, Image, Modal,
  ScrollView, StyleSheet, TouchableOpacity, View
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader } from '../../components/AppHeader';
import { UserAvatar } from '../../components/UserAvatar'; // <--- НОВЫЙ КОМПОНЕНТ
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';
import { useHaptics } from '../../hooks/useHaptics';
import { Share } from 'react-native'; 

const { width } = Dimensions.get('window');
const WORK_HOURS = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'];

export default function SpecialistDetailScreen() {
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { id } = useLocalSearchParams();
  const targetId = Array.isArray(id) ? id[0] : id;

  const [specialist, setSpecialist] = useState<any>(null);
  const [portfolio, setPortfolio] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(true);

  // Бронирование
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [busyDates, setBusyDates] = useState<any>({});
  const [busySlots, setBusySlots] = useState<string[]>([]);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const haptics = useHaptics();
  useEffect(() => { if (targetId) loadData(); }, [targetId, user]);

  async function loadData() {
    setLoading(true);
    try {
      const { data: spec } = await supabase.from('specialist_search_view').select('*').eq('id', targetId).single();
      if (spec) setSpecialist(spec);

      const { data: port } = await supabase.from('portfolio').select('*').eq('specialist_id', targetId);
      if (port) setPortfolio(port);

      const { data: revs } = await supabase.from('reviews').select('*, client:profiles!client_id(full_name, avatar_url)').eq('target_id', targetId).order('created_at', { ascending: false });
      if (revs) setReviews(revs);

      const { data: busyD } = await supabase.from('busy_dates').select('date').eq('specialist_id', targetId);
      const marks: any = {};
      busyD?.forEach(d => marks[d.date] = { disabled: true, disableTouchEvent: true, marked: true, dotColor: theme.colors.error });
      setBusyDates(marks);

      if (user) {
          const { data: fav } = await supabase.from('favorites').select('id').eq('user_id', user.id).eq('target_id', targetId).maybeSingle();
          setIsFavorite(!!fav);
      }
    } catch (e) { console.error(e); }
    setLoading(false);
  }
  const handleShare = async () => {
    try {
      if (!specialist) return;
      await Share.share({
        message: `Посмотри этого мастера: ${specialist.full_name}!\n⭐ Рейтинг: ${Number(specialist.avg_rating).toFixed(1)}\n💰 Цена: от ${specialist.price_start} ₸\n\nНайдено в ServiceApp.`,
      });
    } catch (error: any) {
      console.log(error.message);
    }
  };

  async function onDateSelect(day: any) {
    setSelectedDate(day.dateString);
    setSelectedTime(''); 
    const { data } = await supabase.from('bookings').select('date_time').eq('specialist_id', targetId).ilike('date_time', `${day.dateString}%`).neq('status', 'rejected');
    setBusySlots(data?.map(b => b.date_time.split(' ')[1]) || []);
  }

  async function handleBooking() {
    if (!user) return router.push('/(auth)/login');
    setBookingLoading(true);
    const { error } = await supabase.from('bookings').insert({ 
        client_id: user.id, 
        specialist_id: targetId, 
        date_time: `${selectedDate} ${selectedTime}`, 
        status: 'pending' 
    });
    setBookingLoading(false);

    if (!error) { 
        haptics.success(); // <--- УСПЕХ (приятная вибрация)
        Alert.alert("Успешно", "Заявка отправлена мастеру!"); 
        setModalVisible(false); 
    } else {
        haptics.error(); // <--- ОШИБКА
        Alert.alert("Ошибка", error.message);
    }
  }

  async function toggleFavorite() {
    haptics.medium(); // <--- СРЕДНЯЯ ВИБРАЦИЯ (как тук-тук)
    if (!user) return Alert.alert("Вход", "Сначала авторизуйтесь");
    if (isFavorite) {
      await supabase.from('favorites').delete().eq('user_id', user.id).eq('target_id', targetId);
    } else {
      await supabase.from('favorites').insert({ user_id: user.id, target_id: targetId });
    }
    setIsFavorite(!isFavorite);
  }

  if (loading || !specialist) return <ActivityIndicator size="large" color={theme.colors.primary} style={{flex:1}} />;

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <View style={{ paddingTop: insets.top }}>
        <AppHeader 
            title="Профиль мастера" 
            rightComponent={
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 15 }}>
                    {/* КНОПКА ПОДЕЛИТЬСЯ */}
                    <TouchableOpacity onPress={handleShare}>
                        <Icon name="share" type="feather" color={theme.colors.black} size={22} />
                    </TouchableOpacity>

                    {/* КНОПКА ЛАЙК */}
                    <TouchableOpacity onPress={toggleFavorite}>
                        <Icon name={isFavorite ? "heart" : "heart-o"} type="font-awesome" color={isFavorite ? "#ff4757" : theme.colors.black} />
                    </TouchableOpacity>
                </View>
            } 
        />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        {/* HERO IMAGE (Первое фото или заглушка) */}
        <Image 
            source={{ uri: portfolio[0]?.file_url || 'https://via.placeholder.com/800x600' }} 
            style={styles.heroImg} 
            blurRadius={2} // Немного размываем фон
        />
        
        <View style={[styles.contentContainer, { backgroundColor: theme.colors.background }]}>
            {/* АВАТАР И ИМЯ */}
            <View style={styles.headerSection}>
                <View style={[styles.avatarBorder, { borderColor: theme.colors.background }]}>
                    <UserAvatar avatarUrl={specialist.avatar_url} size={90} />
                </View>
                <Text h4 style={{ color: theme.colors.black, marginTop: 10, textAlign: 'center' }}>{specialist.full_name}</Text>
                <Text style={{ color: theme.colors.primary, fontWeight: '700', marginTop: 4 }}>{specialist.category_name}</Text>
                
                {/* ИНФО ПЛАШКИ */}
                <View style={[styles.statsRow, { borderColor: theme.colors.grey1 }]}>
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.colors.black }]}>{specialist.experience_years} лет</Text>
                        <Text style={styles.statLabel}>Опыт</Text>
                    </View>
                    <View style={[styles.statDivider, { backgroundColor: theme.colors.grey1 }]} />
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.colors.black }]}>⭐ {Number(specialist.avg_rating || 5).toFixed(1)}</Text>
                        <Text style={styles.statLabel}>Рейтинг</Text>
                    </View>
                    <View style={[styles.statDivider, { backgroundColor: theme.colors.grey1 }]} />
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.colors.black }]}>{specialist.price_start} ₸</Text>
                        <Text style={styles.statLabel}>Цена от</Text>
                    </View>
                </View>

                <Text style={[styles.bio, { color: theme.colors.black }]}>
                    {specialist.bio || 'Мастер не добавил описание.'}
                </Text>
            </View>

            {/* ГАЛЕРЕЯ */}
            {portfolio.length > 0 && (
                <View style={styles.section}>
                    <Text h4 style={[styles.sectionTitle, { color: theme.colors.black }]}>Портфолио</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
                        {portfolio.map((item, i) => (
                            <TouchableOpacity key={i} onPress={() => setSelectedImage(item.file_url)}>
                                <Image source={{ uri: item.file_url }} style={styles.portImg} />
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                </View>
            )}

            {/* ОТЗЫВЫ */}
            <View style={styles.section}>
                <View style={styles.rowBetween}>
                    <Text h4 style={[styles.sectionTitle, { color: theme.colors.black }]}>Отзывы ({reviews.length})</Text>
                    <TouchableOpacity onPress={() => router.push({ pathname: '/add-review', params: { targetId, name: specialist.full_name, avatar: specialist.avatar_url } })}>
                        <Text style={{ color: theme.colors.primary, fontWeight: 'bold' }}>Написать</Text>
                    </TouchableOpacity>
                </View>

                {reviews.map((r) => (
                    <View key={r.id} style={[styles.reviewCard, { backgroundColor: theme.colors.grey0 }]}>
                        <UserAvatar avatarUrl={r.client?.avatar_url} size={40} />
                        <View style={{ flex: 1, marginLeft: 12 }}>
                            <View style={styles.rowBetween}>
                                <Text style={{ fontWeight: 'bold', color: theme.colors.black }}>{r.client?.full_name}</Text>
                                <View style={{ flexDirection: 'row' }}>
                                    {[...Array(r.rating)].map((_, i) => <Icon key={i} name="star" type="font-awesome" size={12} color="#FFD700" />)}
                                </View>
                            </View>
                            <Text style={{ color: theme.colors.black, marginTop: 4, opacity: 0.8 }}>{r.comment}</Text>
                        </View>
                    </View>
                ))}
            </View>
        </View>
      </ScrollView>

      {/* FOOTER */}
      <View style={[styles.footer, { backgroundColor: theme.colors.background, borderTopColor: theme.colors.grey1 }]}>
          <TouchableOpacity 
             style={[styles.chatBtn, { borderColor: theme.colors.grey1 }]} 
             onPress={() => router.push(`/chat/${targetId}`)}
          >
              <Icon name="message-circle" type="feather" color={theme.colors.primary} size={24} />
          </TouchableOpacity>
          <Button 
             title="Записаться" 
             onPress={() => setModalVisible(true)} 
             buttonStyle={{ backgroundColor: theme.colors.primary, borderRadius: 16, height: 56 }} 
             containerStyle={{ flex: 1 }} 
          />
      </View>

      {/* MODAL PHOTO */}
      <Modal visible={!!selectedImage} transparent animationType="fade">
          <View style={styles.modalBg}>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setSelectedImage(null)}><Icon name="x" type="feather" color="white" size={30} /></TouchableOpacity>
              {selectedImage && <Image source={{ uri: selectedImage }} style={styles.fullImg} resizeMode="contain" />}
          </View>
      </Modal>

      {/* MODAL BOOKING */}
      <Modal visible={modalVisible} animationType="slide" transparent>
          <View style={styles.modalOverlay}>
              <View style={[styles.modalContent, { backgroundColor: theme.colors.background }]}>
                  <Text h4 style={{ textAlign: 'center', marginBottom: 20, color: theme.colors.black }}>Дата и время</Text>
                  <Calendar 
                    onDayPress={onDateSelect} 
                    markedDates={{ ...busyDates, [selectedDate]: { selected: true, selectedColor: theme.colors.primary } }}
                    theme={{ 
                        calendarBackground: 'transparent', 
                        dayTextColor: theme.colors.black, 
                        monthTextColor: theme.colors.black,
                        arrowColor: theme.colors.primary 
                    }}
                  />
                  {selectedDate ? (
                      <View style={{ marginTop: 20 }}>
                          <Text style={{ marginBottom: 10, color: 'gray' }}>Свободное время:</Text>
                          <View style={styles.chipsRow}>
                              {WORK_HOURS.map(time => (
                                  <Chip 
                                    key={time} title={time} disabled={busySlots.includes(time)}
                                    type={selectedTime === time ? 'solid' : 'outline'}
                                    onPress={() => setSelectedTime(time)}
                                    containerStyle={{ margin: 3 }}
                                    buttonStyle={selectedTime === time ? { backgroundColor: theme.colors.primary } : { borderColor: theme.colors.grey1 }}
                                    titleStyle={selectedTime === time ? { color: '#fff' } : { color: theme.colors.black }}
                                  />
                              ))}
                          </View>
                      </View>
                  ) : null}
                  <Button title="Подтвердить" loading={bookingLoading} disabled={!selectedTime} onPress={handleBooking} containerStyle={{ marginTop: 20 }} />
                  <Button title="Отмена" type="clear" onPress={() => setModalVisible(false)} />
              </View>
          </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  heroImg: { width: '100%', height: 250, opacity: 0.9 },
  contentContainer: { marginTop: -40, borderTopLeftRadius: 30, borderTopRightRadius: 30, paddingHorizontal: 20, paddingBottom: 20 },
  headerSection: { alignItems: 'center', marginBottom: 20 },
  avatarBorder: { marginTop: -50, borderWidth: 5, borderRadius: 50 },
  statsRow: { flexDirection: 'row', marginTop: 20, borderWidth: 1, borderRadius: 16, padding: 15, width: '100%', justifyContent: 'space-between' },
  statItem: { alignItems: 'center', flex: 1 },
  statDivider: { width: 1, height: '100%' },
  statValue: { fontSize: 16, fontWeight: '800' },
  statLabel: { fontSize: 11, color: 'gray', textTransform: 'uppercase', marginTop: 2 },
  bio: { textAlign: 'center', marginTop: 15, lineHeight: 22, opacity: 0.8 },
  section: { marginTop: 30 },
  sectionTitle: { marginBottom: 15, fontSize: 18, fontWeight: '800' },
  portImg: { width: 130, height: 180, borderRadius: 16 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  reviewCard: { flexDirection: 'row', padding: 16, borderRadius: 16, marginBottom: 12 },
  footer: { position: 'absolute', bottom: 0, width: '100%', flexDirection: 'row', padding: 16, paddingBottom: 30, borderTopWidth: 1, gap: 12 },
  chatBtn: { width: 56, height: 56, borderRadius: 16, borderWidth: 1, justifyContent: 'center', alignItems: 'center' },
  modalBg: { flex: 1, backgroundColor: 'black', justifyContent: 'center' },
  closeBtn: { position: 'absolute', top: 50, right: 20, zIndex: 10 },
  fullImg: { width: '100%', height: '80%' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { padding: 25, borderTopLeftRadius: 30, borderTopRightRadius: 30 },
  chipsRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' },
});