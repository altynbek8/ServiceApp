import { Icon, Text, useTheme } from '@rneui/themed';
import { router, useFocusEffect } from 'expo-router';
import React, { useState } from 'react';
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { UserAvatar } from '../../components/UserAvatar'; // <--- Наш компонент
import { sendPushNotification } from '../../lib/push';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../providers/AuthProvider';

export default function VenueHome() {
  const { theme } = useTheme();
  const { user, isLoading } = useAuth();
  const insets = useSafeAreaInsets();
  
  const [bookings, setBookings] = useState<any[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(React.useCallback(() => { if (!isLoading && user) fetchBookings(); }, [user, isLoading]));

  async function fetchBookings() {
    if (!user) return;
    const { data } = await supabase.from('bookings').select(`*, client:profiles!client_id (full_name, avatar_url, phone)`).eq('specialist_id', user.id).order('created_at', { ascending: false });
    setBookings(data || []); setLoadingData(false); setRefreshing(false);
  }

  async function updateStatus(id: string, clientId: string, status: string) {
    // Оптимистичное обновление
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status } : b));
    
    const { error } = await supabase.from('bookings').update({ status }).eq('id', id);
    if (!error) {
        let title = 'Статус брони', body = 'Есть новости по вашей брони.';
        if (status === 'confirmed') { title = 'Бронь подтверждена! ✅'; body = 'Ждем вас в назначенное время.'; }
        else if (status === 'rejected') { title = 'Мест нет ❌'; body = 'К сожалению, заведение не может принять бронь.'; }
        else if (status === 'completed') { title = 'Спасибо за визит! 🎉'; body = 'Будем рады видеть вас снова.'; }
        await sendPushNotification(clientId, title, body);
    }
  }

  const getStatusInfo = (status: string) => {
    switch(status) {
        case 'confirmed': return { label: 'Ожидаем гостей', color: '#fff', bg: theme.colors.primary, icon: 'check-circle' };
        case 'rejected': return { label: 'Отменено', color: theme.colors.error, bg: '#FEE2E2', icon: 'x-circle' };
        case 'completed': return { label: 'Гости посетили', color: '#fff', bg: '#10B981', icon: 'award' };
        default: return { label: 'Новая бронь', color: '#F59E0B', bg: '#FFFBEB', icon: 'bell' };
    }
  };

  const renderItem = ({ item }: { item: any }) => {
    const status = getStatusInfo(item.status);
    const [date, time] = item.date_time.split(' ');

    return (
      <View style={[styles.card, { backgroundColor: theme.colors.grey0 }]}>
        {/* Хедер карточки */}
        <View style={styles.cardHeader}>
            <View>
                <Text style={{ fontSize: 18, fontWeight: '900', color: theme.colors.black }}>{time}</Text>
                <Text style={{ fontSize: 12, color: 'gray', fontWeight: '600' }}>{date}</Text>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
                <Icon name={status.icon} type="feather" size={12} color={item.status === 'confirmed' || item.status === 'completed' ? '#fff' : status.color} />
                <Text style={[styles.statusText, { color: item.status === 'confirmed' || item.status === 'completed' ? '#fff' : status.color }]}>{status.label}</Text>
            </View>
        </View>

        {/* Клиент */}
        <View style={styles.clientRow}>
            <UserAvatar avatarUrl={item.client?.avatar_url} size={50} />
            <View style={{ marginLeft: 12, flex: 1 }}>
                <Text style={[styles.clientName, { color: theme.colors.black }]}>{item.client?.full_name}</Text>
                <Text style={{ fontSize: 12, color: 'gray' }}>Гость</Text>
            </View>
            <TouchableOpacity 
                style={[styles.chatBtn, { backgroundColor: theme.colors.grey1 }]}
                onPress={() => router.push(`/chat/${item.client_id}`)}
            >
                <Icon name="message-circle" type="feather" size={20} color={theme.colors.primary} />
            </TouchableOpacity>
        </View>

        {item.message && (
            <View style={[styles.msgBox, { backgroundColor: theme.colors.background }]}>
                <Text style={{ color: theme.colors.grey2, fontStyle: 'italic', fontSize: 13 }}>
                    "{item.message}"
                </Text>
            </View>
        )}

        {/* Действия */}
        <View style={styles.actionRow}>
            {item.status === 'pending' && (
                <>
                    <TouchableOpacity 
                        style={[styles.btn, { backgroundColor: '#FEE2E2', flex: 1, marginRight: 8 }]} 
                        onPress={() => updateStatus(item.id, item.client_id, 'rejected')}
                    >
                        <Text style={{ color: theme.colors.error, fontWeight: '800' }}>Нет мест</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                        style={[styles.btn, { backgroundColor: theme.colors.primary, flex: 1 }]} 
                        onPress={() => updateStatus(item.id, item.client_id, 'confirmed')}
                    >
                        <Text style={{ color: '#fff', fontWeight: '800' }}>Подтвердить</Text>
                    </TouchableOpacity>
                </>
            )}

            {item.status === 'confirmed' && (
                <TouchableOpacity 
                    style={[styles.btn, { backgroundColor: '#10B981', flex: 1 }]} 
                    onPress={() => updateStatus(item.id, item.client_id, 'completed')}
                >
                    <Icon name="check" type="feather" color="#fff" style={{ marginRight: 8 }} />
                    <Text style={{ color: '#fff', fontWeight: '800' }}>Визит состоялся</Text>
                </TouchableOpacity>
            )}
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background, paddingTop: insets.top + 20 }]}>
      <View style={styles.header}>
        <View>
            <Text style={{ color: theme.colors.grey2, fontWeight: '600' }}>Управление</Text>
            <Text h3 style={{ color: theme.colors.black, fontWeight: '900' }}>Бронирования</Text>
        </View>
        <View style={[styles.badgeCount, { backgroundColor: theme.colors.primary }]}>
             <Text style={{ color: '#fff', fontWeight: 'bold' }}>{bookings.filter(b => b.status === 'pending').length}</Text>
        </View>
      </View>

      {loadingData ? (
        <ActivityIndicator size="large" color={theme.colors.primary} style={{ marginTop: 50 }} />
      ) : (
        <FlatList
          data={bookings}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 20, paddingBottom: 100 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchBookings(); }} tintColor={theme.colors.primary} />}
          ListEmptyComponent={
            <View style={styles.empty}>
                <Icon name="inbox" type="feather" size={60} color={theme.colors.grey2} />
                <Text style={{ color: theme.colors.grey2, marginTop: 15 }}>Бронирований пока нет</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 25, marginBottom: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  badgeCount: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  card: { borderRadius: 24, padding: 20, marginBottom: 15, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10, elevation: 3 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12, gap: 5 },
  statusText: { fontSize: 11, fontWeight: '800' },
  clientRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  clientName: { fontSize: 16, fontWeight: '700' },
  chatBtn: { width: 44, height: 44, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  msgBox: { padding: 12, borderRadius: 12, marginBottom: 15 },
  actionRow: { flexDirection: 'row' },
  btn: { height: 50, borderRadius: 14, justifyContent: 'center', alignItems: 'center', flexDirection: 'row' },
  empty: { flex: 1, alignItems: 'center', marginTop: 100 }
});