import { createTheme, ThemeProvider } from '@rneui/themed';
import * as NavigationBar from 'expo-navigation-bar';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { Platform, useColorScheme, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from '../providers/AuthProvider';

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  
  // Slate-900 для темной, Slate-50 для светлой
  const bgColor = isDark ? '#0F172A' : '#F8FAFC'; 

  useEffect(() => {
    async function prepareNav() {
      if (Platform.OS === 'android') {
        await NavigationBar.setBackgroundColorAsync(bgColor);
        await NavigationBar.setButtonStyleAsync(isDark ? 'light' : 'dark');
      }
    }
    prepareNav();
  }, [isDark]);

  const theme = createTheme({
    lightColors: {
      primary: '#6366F1', // Indigo 500 (Твой основной цвет)
      secondary: '#EC4899', // Pink 500 (Для акцентов)
      background: '#F8FAFC', // Очень светлый серо-голубой, не чисто белый
      grey0: '#FFFFFF', // Чисто белый для карточек
      grey1: '#E2E8F0', // Границы и разделители
      grey2: '#64748B', // Вторичный текст
      grey3: '#94A3B8', // Третичный текст (placeholder)
      black: '#1E293B', // Темно-синий текст (читается лучше черного)
      white: '#FFFFFF',
      error: '#EF4444',
      success: '#10B981',
      warning: '#F59E0B',
    },
    darkColors: {
      primary: '#818CF8', 
      secondary: '#F472B6',
      background: '#0F172A', 
      grey0: '#1E293B', // Карточки темно-синие
      grey1: '#334155',
      grey2: '#94A3B8',
      grey3: '#475569',
      black: '#F8FAFC', 
      white: '#0F172A',
      error: '#F87171',
      success: '#34D399',
      warning: '#FBBF24',
    },
    mode: isDark ? 'dark' : 'light',
    components: {
      Button: {
        buttonStyle: {
          borderRadius: 14,
          height: 54,
          paddingVertical: 0, 
        },
        titleStyle: {
          fontWeight: '700',
          fontSize: 16,
          letterSpacing: 0.5,
        },
        containerStyle: {
          borderRadius: 14,
        }
      },
      Input: {
        inputContainerStyle: {
          borderBottomWidth: 0,
          backgroundColor: isDark ? '#1E293B' : '#FFFFFF',
          borderRadius: 14,
          height: 54,
          paddingHorizontal: 16,
          borderWidth: 1,
          borderColor: isDark ? '#334155' : '#E2E8F0',
        },
        containerStyle: {
          paddingHorizontal: 0,
          marginBottom: 16,
        },
        labelStyle: {
          fontSize: 13,
          fontWeight: '600',
          color: isDark ? '#94A3B8' : '#64748B',
          marginBottom: 8,
          marginLeft: 4,
        },
        inputStyle: {
          fontSize: 16,
        }
      },
      Card: {
        containerStyle: {
          borderRadius: 20,
          padding: 16,
          borderWidth: 0,
          elevation: 4,
          shadowColor: '#6366F1',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.05,
          shadowRadius: 10,
          margin: 0,
          marginBottom: 16,
        }
      }
    },
  });

  return (
    <SafeAreaProvider>
      <ThemeProvider theme={theme}>
        <AuthProvider>
          <StatusBar style={isDark ? 'light' : 'dark'} backgroundColor={bgColor} />
          <View style={{ flex: 1, backgroundColor: bgColor }}>
            <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: bgColor }, animation: 'slide_from_right' }}>
              <Stack.Screen name="index" />
              <Stack.Screen name="(auth)" />
              <Stack.Screen name="(client)" />
              <Stack.Screen name="(specialist)" />
              <Stack.Screen name="(venue)" />
            </Stack>
          </View>
        </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}