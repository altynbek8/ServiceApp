// @ts-ignore
import { FileSystemUploadType, uploadAsync } from 'expo-file-system/legacy';
import { supabase } from './supabase';

const SUPABASE_URL = 'https://hhpxgxpntohduvbeucpp.supabase.co';

export async function uploadFileToSupabase(bucket: string, uri: string, fileName: string) {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token;
    if (!token) throw new Error("Нет авторизации");

    const uploadUrl = `${SUPABASE_URL}/storage/v1/object/${bucket}/${fileName}`;
    const isVideo = uri.toLowerCase().endsWith('.mp4') || uri.toLowerCase().endsWith('.mov');
    const contentType = isVideo ? 'video/mp4' : 'image/jpeg';

    const response = await uploadAsync(uploadUrl, uri, {
      httpMethod: 'POST',
      uploadType: FileSystemUploadType ? FileSystemUploadType.BINARY_CONTENT : 1, 
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': contentType,
        'x-upsert': 'true',
      },
    });

    if (response.status !== 200) throw new Error(`Upload failed: ${response.status}`);

    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(fileName);
    return urlData.publicUrl;
  } catch (error: any) {
    console.log('Upload error:', error.message);
    throw error;
  }
}