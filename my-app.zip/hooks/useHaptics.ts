import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

export const useHaptics = () => {
  // Легкий клик (для навигации, кнопок)
  const light = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Средний удар (для лайков, важных переключателей)
  const medium = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
  };

  // Вибрация успеха (бзз-бзз)
  const success = () => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  // Вибрация ошибки (бзз-бзз-бзз)
  const error = () => {
    if (Platform.OS !== 'web') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  // Для скроллеров и барабанов (очень легкая)
  const selection = () => {
    if (Platform.OS !== 'web') {
        Haptics.selectionAsync();
    }
  }

  return { light, medium, success, error, selection };
};