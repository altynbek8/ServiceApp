import { Icon, Text, useTheme } from '@rneui/themed';
import { router } from 'expo-router';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { useHaptics } from '../hooks/useHaptics'; // <--- 1. Импорт
import { UserAvatar } from './UserAvatar';

interface ProfileCardProps {
  item: any;
  type?: 'specialist' | 'venue';
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ item, type = 'specialist' }) => {
  const { theme } = useTheme();
  const haptics = useHaptics(); // <--- 2. Инит

  const handlePress = () => {
    haptics.light(); // <--- 3. Вибрация при переходе
    const route = type === 'venue' ? `/venue-details/${item.id}` : `/specialist-details/${item.id}`;
    router.push(route as any);
  };

  const displayName = item.full_name || item.profiles?.full_name || 'Без имени';
  const displayCity = item.city || item.profiles?.city || 'Алматы';
  const rating = item.avg_rating > 0 ? Number(item.avg_rating).toFixed(1) : "NEW";
  const avatarUrl = item.avatar_url || item.profiles?.avatar_url;
  const category = item.category_name || 'Услуги';
  const reviewCount = item.review_count || 0;
  
  const price = item.price_start ? `от ${item.price_start} ₸` : null;
  const capacity = item.capacity ? `до ${item.capacity} чел.` : null;

  let badge = null;
  if (Number(rating) >= 4.8) {
      badge = { text: 'Топ выбор', color: '#10B981', icon: 'award' };
  } else if (reviewCount > 10) {
      badge = { text: 'Популярен', color: '#F59E0B', icon: 'fire' };
  } else if (item.price_start && item.price_start < 5000) {
      badge = { text: 'Выгодно', color: '#6366f1', icon: 'trending-down' };
  }

  return (
    <TouchableOpacity 
      activeOpacity={0.9} 
      onPress={handlePress}
      style={[styles.container, { 
          backgroundColor: theme.colors.grey0, 
          shadowColor: theme.mode === 'dark' ? '#000' : '#ccc', 
      }]}
    >
      <View style={styles.mainRow}>
        <View style={styles.avatarCol}>
            <UserAvatar avatarUrl={avatarUrl} size={65} />
            <View style={[styles.ratingBadge, { backgroundColor: theme.colors.background, borderColor: theme.colors.grey1 }]}>
                <Icon name="star" type="font-awesome" size={10} color="#F59E0B" />
                <Text style={[styles.ratingText, { color: theme.colors.black }]}>{rating}</Text>
            </View>
        </View>

        <View style={styles.infoCol}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1 }}>
                    <Text style={[styles.name, { color: theme.colors.black }]} numberOfLines={1}>
                        {displayName}
                    </Text>
                    <Text style={[styles.category, { color: theme.colors.grey2 }]} numberOfLines={1}>
                        {category} • {displayCity}
                    </Text>
                </View>
                {badge && (
                    <View style={[styles.smartBadge, { backgroundColor: badge.color + '15' }]}>
                        <Icon name={badge.icon} type="feather" size={10} color={badge.color} style={{ marginRight: 3 }} />
                        <Text style={[styles.smartBadgeText, { color: badge.color }]}>{badge.text}</Text>
                    </View>
                )}
            </View>

            <View style={{ height: 8 }} />

            <View style={styles.bottomRow}>
                {type === 'specialist' && item.experience_years > 0 && (
                    <View style={[styles.chip, { backgroundColor: theme.colors.grey1 }]}>
                        <Text style={[styles.chipText, { color: theme.colors.grey3 }]}>{item.experience_years} г. опыт</Text>
                    </View>
                )}
                {type === 'venue' && capacity && (
                    <View style={[styles.chip, { backgroundColor: theme.colors.grey1 }]}>
                        <Icon name="users" type="feather" size={10} color={theme.colors.grey3} style={{marginRight: 4}}/>
                        <Text style={[styles.chipText, { color: theme.colors.grey3 }]}>{capacity}</Text>
                    </View>
                )}

                <View style={{ flex: 1 }} /> 
                {price ? (
                    <Text style={[styles.price, { color: theme.colors.primary }]}>{price}</Text>
                ) : (
                    <Text style={{ fontSize: 12, color: theme.colors.grey3 }}>Цена не указана</Text>
                )}
            </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 22, padding: 16, marginBottom: 16,
    shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 3,
  },
  mainRow: { flexDirection: 'row', alignItems: 'flex-start' },
  avatarCol: { alignItems: 'center', marginRight: 16 },
  ratingBadge: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4,
    borderRadius: 12, marginTop: -10, borderWidth: 1, gap: 3, zIndex: 1,
  },
  ratingText: { fontSize: 11, fontWeight: '800' },
  infoCol: { flex: 1, justifyContent: 'space-between', paddingVertical: 2 },
  name: { fontSize: 17, fontWeight: '800', marginBottom: 4 },
  category: { fontSize: 13, fontWeight: '500' },
  bottomRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, flexDirection: 'row', alignItems: 'center' },
  chipText: { fontSize: 11, fontWeight: '700' },
  price: { fontSize: 16, fontWeight: '900' },
  smartBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  smartBadgeText: { fontSize: 10, fontWeight: '800', textTransform: 'uppercase' }
});