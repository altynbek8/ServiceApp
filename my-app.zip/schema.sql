-- ==========================================================
-- 1. ТАБЛИЦЫ (ФУНДАМЕНТ)
-- ==========================================================

-- Профили пользователей (расширение стандартной таблицы Auth)
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT,
  avatar_url TEXT,
  role TEXT CHECK (role IN ('client', 'specialist', 'venue', 'admin')),
  city TEXT,
  phone TEXT,
  push_token TEXT,
  balance INTEGER DEFAULT 0,
  is_admin BOOLEAN DEFAULT FALSE,
  is_banned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Категории услуг
CREATE TABLE public.categories (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT CHECK (type IN ('specialist', 'venue')),
  image_url TEXT,
  bg_color TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Дополнительная информация для Специалистов
CREATE TABLE public.specialist_profiles (
  id UUID REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
  bio TEXT,
  experience_years INTEGER DEFAULT 0,
  price_start INTEGER DEFAULT 0,
  category_id INTEGER REFERENCES public.categories(id) ON DELETE SET NULL
);

-- Дополнительная информация для Заведений
CREATE TABLE public.venue_profiles (
  id UUID REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
  description TEXT,
  address TEXT,
  capacity INTEGER DEFAULT 0,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  category_id INTEGER REFERENCES public.categories(id) ON DELETE SET NULL
);

-- Личные сообщения (Чат 1 на 1)
CREATE TABLE public.messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  sender_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  receiver_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Общие чаты категорий
CREATE TABLE public.category_messages (
  id SERIAL PRIMARY KEY,
  category_id INTEGER REFERENCES public.categories(id) ON DELETE CASCADE NOT NULL,
  sender_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Система бронирований
CREATE TABLE public.bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  specialist_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  date_time TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, confirmed, rejected, completed
  message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Портфолио (Фото и Видео)
CREATE TABLE public.portfolio (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  specialist_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT DEFAULT 'image', -- image, video
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Отзывы
CREATE TABLE public.reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  target_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5) NOT NULL,
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT no_self_review CHECK (client_id <> target_id)
);

-- Избранное
CREATE TABLE public.favorites (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  target_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, target_id)
);

-- Уведомления
CREATE TABLE public.notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  title TEXT,
  body TEXT,
  data JSONB DEFAULT '{}'::jsonb,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- График работы (Выходные)
CREATE TABLE public.busy_dates (
  id SERIAL PRIMARY KEY,
  specialist_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  date TEXT NOT NULL
);

-- ==========================================================
-- 2. ПРЕДСТАВЛЕНИЯ (VIEWS) - ДЛЯ БЫСТРОГО ПОИСКА
-- ==========================================================

-- Поиск специалистов с расчетом рейтинга
CREATE OR REPLACE VIEW specialist_search_view AS
SELECT 
    sp.id, sp.bio, sp.experience_years, sp.price_start, sp.category_id,
    p.full_name, p.avatar_url, p.city, p.is_banned,
    cat.name as category_name,
    COALESCE(AVG(r.rating), 0) as avg_rating,
    COUNT(r.id) as review_count
FROM specialist_profiles sp
JOIN profiles p ON sp.id = p.id
JOIN categories cat ON sp.category_id = cat.id
LEFT JOIN reviews r ON sp.id = r.target_id
GROUP BY sp.id, p.id, cat.name;

-- Глобальный поиск по всей базе
CREATE OR REPLACE VIEW global_search_view AS
SELECT 
    p.id, p.full_name, p.avatar_url, p.city, p.role,
    cat.name as category_name,
    COALESCE(sp.bio, vp.description) as description
FROM profiles p
LEFT JOIN specialist_profiles sp ON p.id = sp.id
LEFT JOIN venue_profiles vp ON p.id = vp.id
LEFT JOIN categories cat ON (sp.category_id = cat.id OR vp.category_id = cat.id)
WHERE p.is_banned = false AND p.role IN ('specialist', 'venue');

-- ==========================================================
-- 3. ФУНКЦИИ (МОЗГИ БАЗЫ)
-- ==========================================================

-- Получение списка активных чатов
CREATE OR REPLACE FUNCTION get_my_chats()
RETURNS TABLE (partner_id UUID, full_name TEXT, avatar_url TEXT, last_message TEXT, last_message_time TIMESTAMPTZ) AS $$
BEGIN
  RETURN QUERY
  WITH last_messages AS (
    SELECT
      CASE WHEN m.sender_id = auth.uid() THEN m.receiver_id ELSE m.sender_id END AS p_id,
      m.content, m.created_at,
      ROW_NUMBER() OVER (PARTITION BY CASE WHEN m.sender_id = auth.uid() THEN m.receiver_id ELSE m.sender_id END ORDER BY m.created_at DESC) as rn
    FROM messages m
    WHERE m.sender_id = auth.uid() OR m.receiver_id = auth.uid()
  )
  SELECT p.id, p.full_name, p.avatar_url, lm.content, lm.created_at
  FROM last_messages lm
  JOIN profiles p ON p.id = lm.p_id
  WHERE lm.rn = 1
  ORDER BY lm.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Лента видео (Reels)
CREATE OR REPLACE FUNCTION get_video_feed()
RETURNS TABLE (id UUID, file_url TEXT, description TEXT, user_id UUID, full_name TEXT, avatar_url TEXT, role TEXT) AS $$
BEGIN
  RETURN QUERY
  SELECT p.id, p.file_url, COALESCE(sp.bio, vp.description, '...') as description, prof.id, prof.full_name, prof.avatar_url, prof.role
  FROM portfolio p
  JOIN profiles prof ON p.specialist_id = prof.id
  LEFT JOIN specialist_profiles sp ON prof.id = sp.id
  LEFT JOIN venue_profiles vp ON prof.id = vp.id
  WHERE p.file_type = 'video'
  ORDER BY p.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Удаление своего аккаунта
CREATE OR REPLACE FUNCTION delete_own_account()
RETURNS void AS $$
BEGIN
  DELETE FROM auth.users WHERE id = auth.uid();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==========================================================
-- 4. ТРИГГЕРЫ (АВТОМАТИЗАЦИЯ)
-- ==========================================================

-- Авто-создание профиля при регистрации
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, avatar_url)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'avatar_url');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Уведомление о новом сообщении
CREATE OR REPLACE FUNCTION handle_new_message_notification()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO notifications (user_id, title, body, data)
  VALUES (NEW.receiver_id, 'Новое сообщение', 'У вас новое сообщение в чате', jsonb_build_object('sender_id', NEW.sender_id, 'type', 'chat'));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_new_message
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION handle_new_message_notification();